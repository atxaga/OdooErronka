from odoo import models, fields

class ZubiriStudent(models.Model):
    _name = 'xz.student'
    _description = 'Ikasleen kudeaketa'

    name = fields.Char(string='Izena', required=True)
    apellido = fields.Char(string='Abizena')
    email = fields.Char(string='Email Korporatiboa')
    zikloa = fields.Selection([
        ('ms', 'MS'),
        ('ssa', 'SSA'),
        ('wg', 'WG'),
        ('paag', 'PAAG')
    ], string='Zikloa')
    
    classroom_id = fields.Many2one('xz.classroom', string='Gela')
    equipment_id = fields.Many2one('xz.equipment', string='PC Esleitua')

    # One2many erlazioak
    notes_ids = fields.One2many('xz.note', 'student_id', string='Oharrak')
    attendance_ids = fields.One2many('xz.attendance', 'student_id', string='Asistentziak')


class ZubiriNote(models.Model):
    _name = 'xz.note'
    _description = 'Ikaslearen oharrak'

    name = fields.Char(string='Titulua')
    date = fields.Date(string='Data')
    student_id = fields.Many2one('xz.student', string='Ikaslea')
    content = fields.Text(string='Edukia')


class ZubiriAttendance(models.Model):
    _name = 'xz.attendance'
    _description = 'Asistentziak'

    student_id = fields.Many2one('xz.student', string='Ikaslea')
    date = fields.Date(string='Data')
    state = fields.Selection([
        ('present','Aurkitua'),
        ('absent','Ez Aurkitua')
    ], string='Egoera')
